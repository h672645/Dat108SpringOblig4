package objects;

public enum Kjonn {
	mann, kvinne;
}
