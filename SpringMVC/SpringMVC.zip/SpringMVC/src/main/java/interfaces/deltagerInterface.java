//package interfaces;
//
//import org.springframework.data.jpa.repository.JpaRepository;
//
//import objekt.Deltager;
//
//public interface deltagerInterface extends JpaRepository<Deltager, String> {
//
//	Deltager findByFornavn(String navn);
//
//}
